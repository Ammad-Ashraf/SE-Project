import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import org.w3c.dom.*;

public class XPDLParser 
{
    public static void main(String[] args)
    {
        try {
        	
            File xpdlFile = new File("D:\\Semester -04\\Business Process Engineering\\Assignments\\XPDLParser\\SCM.xpdl");
            // DocumentBuilderFactory provides Factory API through which an application get
            // a parser.The parser constructs DOM object trees from XML structure of the XPDL file
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            // Storing the DOM tree in Document
            Document doc = dBuilder.parse(xpdlFile);
            // Getting root element of tree <Package>
            doc.getDocumentElement().normalize();

            // Counters for BPMN elements
            
            int totalEvents = 0, startEvents = 0, intermediateEvents = 0, endEvents = 0; // Events
            int totalActivities=0; // Total Activities (Subprocesses+Total Tasks)
            int totalTasks = 0, userTasks = 0, serviceTasks = 0, scriptTasks = 0, manualTasks = 0,businessRuleTasks=0;
            int sendTasks=0,receiveTasks=0,noneTasks=0; // Types of Tasks
            int subProcesses = 0;// total Sub-processes 
            int totalGateways = 0;
            int Parallel = 0, Exclusive = 0, Inclusive = 0,eventBased=0;
            int EeventBased=0,PeventBased=0,complex=0; // Types of GateWays
            int totalSwimlanes = 0, pools = 0, lanes = 0; // Swimlanes
            int totalArtifacts=0,dataObjects=0,groups=0,annotations=0; // artifacts
            int connectingObjects=0,seqFLows=0,mesgFlows=0,associations=0; // connectingObjects
            
            // Parsing document and counting elements
            
            // Getting All events
            NodeList events = doc.getElementsByTagName("Event");
            for (int i = 0; i < events.getLength(); i++) 
            {
                Node event = events.item(i);
                if (event.getNodeType() == Node.ELEMENT_NODE)
                {
                    Element eventElement = (Element) event;
                    // Checking for specific child elements
                    if (eventElement.getElementsByTagName("StartEvent").getLength() > 0)
                    {
                        startEvents++;
                    }
                    if (eventElement.getElementsByTagName("IntermediateEvent").getLength() > 0)
                    {
                        intermediateEvents++;
                    }
                    if (eventElement.getElementsByTagName("EndEvent").getLength() > 0)
                    {
                        endEvents++;
                    }
                }
            }
            totalEvents=startEvents+intermediateEvents+endEvents;

            // Getting all task elements
            NodeList tasks = doc.getElementsByTagName("Task");
            for (int i = 0; i < tasks.getLength(); i++)
            {
                Node taskNode = tasks.item(i);
                if (taskNode.getNodeType() == Node.ELEMENT_NODE) 
                {
                    Element taskElement = (Element) taskNode;
                    totalTasks++;
                    // Check for specific child task types
                    if (taskElement.getElementsByTagName("TaskUser").getLength() > 0) {
                        userTasks++;
                    } else if (taskElement.getElementsByTagName("TaskService").getLength() > 0) {
                        serviceTasks++;
                    } else if (taskElement.getElementsByTagName("TaskScript").getLength() > 0) {
                        scriptTasks++;
                    } else if (taskElement.getElementsByTagName("TaskManual").getLength() > 0) {
                        manualTasks++;
                    } else if (taskElement.getElementsByTagName("TaskBusinessRule").getLength() > 0) {
                        businessRuleTasks++;
                    } else if (taskElement.getElementsByTagName("TaskSend").getLength() > 0) {
                        sendTasks++;
                    } else if (taskElement.getElementsByTagName("TaskReceive").getLength() > 0) {
                        receiveTasks++;
                    } else {
                        noneTasks++; 
                    }
                }
            }
            
            // Get all gateway elements, which are Activity elements of type Route
            NodeList gateways = doc.getElementsByTagName("Activity");
            for (int i = 0; i < gateways.getLength(); i++) 
            {
                Node gatewayNode = gateways.item(i);
                if (gatewayNode.getNodeType() == Node.ELEMENT_NODE)
                {
                    Element gatewayElement = (Element) gatewayNode;
                    Element routeElement = (Element) gatewayElement.getElementsByTagName("Route").item(0);
                    if (routeElement != null) 
                    {
                        String gatewayType = routeElement.getAttribute("GatewayType");

                        switch (gatewayType) 
                        {
                            case "Parallel":
                                Parallel++;
                                break;
                            case "Exclusive":
                                Exclusive++;
                                break;
                            case "Inclusive":
                                Inclusive++;
                                break;
                            case "EventBased":
                                eventBased++;
                                break;
                            case "Complex":
                                complex++;
                                break;
                            case "Exclusive-Event":
                            	EeventBased++;
                            case "Parallel-Event":
                            	PeventBased++;
                            
                        }
                    }
                }
                
            }
            
            // Count all artifacts
            NodeList artifacts = doc.getElementsByTagName("Artifact");
            for (int i = 0; i < artifacts.getLength(); i++)
            {
                Element artifact = (Element) artifacts.item(i);
                totalArtifacts++;
                String artifactType = artifact.getAttribute("ArtifactType");
                switch (artifactType)
                {
                    case "DataObject":
                        dataObjects++;
                        break;
                    case "Group":
                        groups++;
                        break;
                    case "Annotation":
                        annotations++;
                        break;
                }
            }

            // Count all connecting objects
            
            NodeList connectionsSeq = doc.getElementsByTagName("Transition"); // For sequence Flows
            seqFLows=connectionsSeq.getLength();
            NodeList connectionsMesg=doc.getElementsByTagName("MessageFLow");
            mesgFlows=connectionsMesg.getLength();
            NodeList connectionsAss=doc.getElementsByTagName("Association");
            associations=connectionsAss.getLength();
            
            // Counting all swimlanes
            NodeList Lanes = doc.getElementsByTagName("Lane"); // lanes
            NodeList Pools=doc.getElementsByTagName("Pool"); // pools
            lanes = Lanes.getLength();
            pools = Pools.getLength();
            totalSwimlanes = lanes + pools;
            
            // Counting all subprocesses
            NodeList subprocesses=doc.getElementsByTagName("SubFlow");
            subProcesses=subprocesses.getLength();
            
            // Counting all activities
            totalActivities=subProcesses+totalTasks;
            
            // Counting all connectING Objects
            connectingObjects=seqFLows+mesgFlows+associations;
            
            // Counting all Gateways
            totalGateways=Exclusive+Inclusive+Parallel+complex+eventBased+EeventBased+PeventBased;
            
           
            System.out.println("----------------------------");
            System.out.println("Summary of BPMN Elements....");
            System.out.println("----------------------------\n");
            System.out.println("Events:");
            System.out.println("-Total Events: " + totalEvents);
            System.out.println("  - Start Events: " + startEvents);
            System.out.println("  - Intermediate Events: " + intermediateEvents);
            System.out.println("  - End Events: " + endEvents);
            System.out.println();
            
            System.out.println("- Total Activities: "+totalActivities);
            System.out.println("Tasks:");
            System.out.println("-Total Tasks: " + totalTasks);
            System.out.println("  - User Tasks: " + userTasks);
            System.out.println("  - Service Tasks: " + serviceTasks);
            System.out.println("  - Script Tasks: " + scriptTasks);
            System.out.println("  - Manual Tasks: " + manualTasks);
            System.out.println("  - Send Tasks: " + sendTasks);
            System.out.println("  - Receive Tasks: " + receiveTasks);
            System.out.println("  - BusinessRule Tasks: " + businessRuleTasks);
            System.out.println("  - None: " + noneTasks);
            System.out.println();
            System.out.println("Sub-Processes:");
            System.out.println("-Total Sub-Processes: "+subProcesses);
            System.out.println();

            System.out.println("Artifacts:");
            System.out.println("- Total Artifacts: " + totalArtifacts);
            System.out.println("  - Data Objects: " + dataObjects);
            System.out.println("  - Groups: " + groups);
            System.out.println("  - Annotations: " + annotations);
            System.out.println();

            System.out.println("Connecting Objects:");
            System.out.println("- Total Connecting Objects: " + connectingObjects);
            System.out.println("  - Sequence Flow: "+ seqFLows);
            System.out.println("  - Message Flow: "+ mesgFlows);
            System.out.println("  - Associations: "+ associations);
            System.out.println();
            
            System.out.println("Gateways:");
            System.out.println("- Total Gateways: " + totalGateways+"\n");
            System.out.println("Exclusive_Gateways_XOR: "+Exclusive);
            System.out.println("Parallel_Gateways_AND: "+Parallel);
            System.out.println("Inclusive_Gateways_OR: "+Inclusive);
            System.out.println("Event Based Gateway: "+eventBased);
            System.out.println("Exclusive Event Based Gateway: "+EeventBased);
            System.out.println("Parallel Event Based Gateway: "+PeventBased);
            System.out.println("Complex Gateway: "+complex);
            System.out.println();
            
            System.out.println("Swimlanes:");
            System.out.println("- Total Swimlanes: " + totalSwimlanes);
            System.out.println(" - Lanes: "+lanes);
            System.out.println(" - Pools: "+pools);
            System.out.println();



        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
 