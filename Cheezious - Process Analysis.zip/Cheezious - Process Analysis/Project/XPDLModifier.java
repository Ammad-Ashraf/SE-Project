
/*
 * 
 * 	DYNAMIC MODIFICATIONS OF XPDL FILE 
 * 	MAIN CLASS  
 * 
 */

public class XPDLModifier
{
    public static void main(String[] args)
    {
        try
        {
            Functions xpdlModifier=new Functions();
            
            // Checking AddActivityTime Function
            xpdlModifier.addActivityTime("D:\\Semester -04\\Business Process Engineering\\Assignments\\XPDLParser\\OrderFulfillment.xpdl");
                        
            // Checking CalculateCT Function
            double cycletime=0.0;
            double cycleTimeeficiency=0.0;
            cycletime=xpdlModifier.CalculateCT(xpdlModifier.modifiedFile_Path);
            cycleTimeeficiency=(cycletime/xpdlModifier.processTime)*100;
            
            System.out.println("Cycle Time : "+cycletime+" minutes ");
            System.out.println("Cycle Time Efficiency : "+cycleTimeeficiency+" % ");
            
            System.out.println();
            
            

            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
