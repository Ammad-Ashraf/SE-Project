import org.w3c.dom.*;

import javax.xml.parsers.*;
import java.io.File;
import java.util.*;

public class ProcessCycleTimeCalculator 
{
			// For storing Activity Duration (Task Duration , Activity ID)
			static class ActivityDuration
			{
			    private String activityId;
			    private double duration;

			    public ActivityDuration(String activityid, double duration)
			    {
			        this.activityId = activityid;
			        this.duration = duration;
			    }
			}
			// For storing Gateways in the Process
			static class GatewayType
			{
				 private List<String> sourceIds;
				 private List<String> targetIds;
				 private String type;

			    public GatewayType(String gttype,List<String> sourceIds,List<String> targetIds)
			    {
			        this.type = gttype;
			        this.sourceIds = new ArrayList<>(sourceIds);
			        this.targetIds = new ArrayList<>(targetIds);
			    }
			}
		
			public static List<ActivityDuration> durations=new ArrayList<>();
		    public static List<GatewayType> gatewayTypes=new ArrayList<>();
		    public static double cycletime=0.0;
		    // Variables to store indices, initialized to -1 to indicate 'not found'
	        static int index1 = -1;
	        static int index2 = -1;
		    
			// Parsing document and store elements
			
		    public static void parseDocument(String filepath) throws Exception 
		    {
		        File inputFile = new File(filepath);
		        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		        Document doc = dBuilder.parse(inputFile);
		        doc.getDocumentElement().normalize();
		        
		        NodeList activities = doc.getElementsByTagName("Activity");
		        // Getting all tasks and their durations
		        
		        for (int i = 0; i < activities.getLength(); i++)
		        {
		            Element activity = (Element) activities.item(i);
		            String id = activity.getAttribute("Id");
		            NodeList tasks = activity.getElementsByTagName("Task");
		            if (tasks.getLength() > 0)
		            {
		                Element task = (Element) tasks.item(0);
		                double duration = Double.parseDouble(task.getAttribute("duration"));
		                durations.add(new ActivityDuration(id,duration));
		            }
		        }
		        
		        // Getting all gateways and their corresponding Activity ID's
		        
		        for (int i = 0; i < activities.getLength(); i++)
		        {
		            Node activityNode = activities.item(i);
		            if (activityNode.getNodeType() == Node.ELEMENT_NODE)
		            {
		                Element activityElement = (Element) activityNode;
		                String gatewayType = null; // Initialize the variable to store the gateway type

			             // First, get the NodeList for the 'Route' element
			             NodeList routeList = activityElement.getElementsByTagName("Route");
	
			             if (routeList != null && routeList.getLength() > 0)
			             {
			                 Node routeNode = routeList.item(0); // Get the first 'Route' node
			                 if (routeNode != null) 
			                 {
			                     NamedNodeMap attributes = routeNode.getAttributes();
			                     if (attributes != null) 
			                     {
			                         Node gatewayTypeNode = attributes.getNamedItem("GatewayType");
			                         if (gatewayTypeNode != null)
			                         {
			                             gatewayType = gatewayTypeNode.getNodeValue(); // Get the value of the GatewayType attribute
			                         }
			                     } 
			                 } 
			             }
		
		                List<String> ingoingTransitions = extractTransitions(activityElement, "Ingoing");
		                List<String> outgoingTransitions = extractTransitions(activityElement, "Outgoing");
		
		                gatewayTypes.add(new GatewayType(gatewayType, ingoingTransitions, outgoingTransitions));
		            }
		        }
		          
		    }
		    
		    // Helper function to get Transitions of gateway
		    
		    private static List<String> extractTransitions(Element activityElement, String type)
		    {
		        NodeList transitionRefsList = activityElement.getElementsByTagName("TransitionRefs");
		        List<String> transitions = new ArrayList<>();
		        for (int j = 0; j < transitionRefsList.getLength(); j++) 
		        {
		            Node transitionRefsNode = transitionRefsList.item(j);
		            if (transitionRefsNode != null)
		            {
		            	if (transitionRefsNode.getNodeType() == Node.ELEMENT_NODE)
			            {
			                Element transitionRefsElement = (Element) transitionRefsNode;
			                if (type.equals(transitionRefsElement.getAttribute("Type")))
			                {
			                    NodeList transitionRefList = transitionRefsElement.getElementsByTagName("TransitionRef");
			                    for (int k = 0; k < transitionRefList.getLength(); k++) 
			                    {
			                        Element transitionRefElement = (Element) transitionRefList.item(k);
			                        transitions.add(transitionRefElement.getAttribute("Id"));
			                    }
			                }
			            }
		            }
		            
		        }
		        return transitions;
		    }
		    
		    //  Calculating Cycle Time 
		    
		    public static double calculateCycleTime() 
		    {
		    	// ID's lsit 
		    	List<String> activityIds = new ArrayList<>();
		    	for (ActivityDuration duration : durations) 
		    	{
		    	    activityIds.add(duration.activityId);
		    	}
		    	
		    	String id="";
		    	boolean find=false;
		    	String gatewayName="";
		    	String outId1="";
		    	String outId2="";
		    	List<String> visited=new ArrayList<>();
		    	
		    	for (ActivityDuration duration : durations) 
		    	{
		    	    id=duration.activityId;
		    	    if(!visited.contains(id))
		    	    {
		    	    	for(GatewayType gateways : gatewayTypes)
			    	    {
			    	    	find=gateways.sourceIds.contains(id);
			    	    	if(find)
			    	    	{
			    	    		gatewayName=gateways.type;
			    	    		
			    	    		if(gatewayName=="Parallel")
			    	    		{
			    	    			cycletime+=getMaxDurationForParallelGateway(gatewayName,gatewayTypes,durations);
			    	    			
			    	    		}else if(gatewayName=="Exclusive")
			    	    		{
			    	    			List<String> outgoingIds =gateways.targetIds;
			    	                
			    	                if (outgoingIds.size() == 2)
			    	                { 
			    	                    outId1 = outgoingIds.get(0);
			    	                    outId2 = outgoingIds.get(1);
			    	                    if(checkIdsAndIndices(activityIds,outId1,outId2))
			    	                    {
			    	                    	for (ActivityDuration dura : durations) 
			    		                    {
			    		                        if (dura.activityId.equals(outId1)||duration.activityId.equals(outId2))
			    		                        {
			    		                        	cycletime+=(dura.duration*0.5); // Assumption Probabilities for every path will be 0.5 
			    		                        	visited.add(dura.activityId);
			    		                        }
			    		                    }
			    	                    }else
			    	                    {
			    	                    	double reworking=0.0;
			    	                    	reworking=(1+0.25)*sumDurations(durations,index2,index1); //Assumption Rejection rate r=0.25
			    	                    	cycletime+=reworking;
			    	                    }
			    	                 
			    	                }
			    	    		}
			    	    		
			    	    	}
			    	    }
			    	    if(find==false)
			    	    {
			    	    	
			    	    	cycletime+=duration.duration;
			    	    }
		    	    }
		    	    
		    	    
		    	}
		    	
		    	return cycletime;
		    }
		    
		    // Helper Function
		    
		    public static double getMaxDurationForParallelGateway(String gatewayName, List<GatewayType> gateways, List<ActivityDuration> durations)
		    {
		        double maxDuration = 0;

		        // Find the specific gateway
		        for (GatewayType gateway : gateways)
		        {
		            if (gatewayName.equals("Parallel"))
		            {
		                List<String> outgoingIds = gateway.targetIds;

		                // Find durations for all outgoing transitions and determine the maximum
		                for (String id : outgoingIds)
		                {
		                    for (ActivityDuration duration : durations) 
		                    {
		                        if (duration.activityId.equals(id))
		                        {
		                            if (duration.duration > maxDuration)
		                            {
		                                maxDuration = duration.duration;
		                            }
		                        }
		                    }
		                }

		                break;
		            }
		        }

		        return maxDuration;
		    }
		    
		    // Helper Function
		    public static boolean checkIdsAndIndices(List<String> activityIds, String id1, String id2)
		    {
		        // Loop through the list to find indices
		        for (int i = 0; i < activityIds.size(); i++)
		        {
		            if (activityIds.get(i).equals(id1))
		            {
		                index1 = i;
		            }
		            if (activityIds.get(i).equals(id2))
		            {
		                index2 = i;
		            }
		        }

		        // Check if both IDs were found and whether they are adjacent
		        if (index1 != -1 && index2 != -1)
		        {
		            if (Math.abs(index1 - index2) == 1)
		            {
		                return true;
		            } else 
		            {
		                return false;
		            }
		        }
		        else
		        {
		            return false;
		        }
		    }
		    
		    //Helper Function
		    public static double sumDurations(List<ActivityDuration> durations, int startIndex, int endIndex)
		    {
		        double totalDuration = 0.0;

		        // Ensure that the indices are in the correct order
		        int start = Math.min(startIndex, endIndex);
		        int end = Math.max(startIndex, endIndex);

		        // Sum durations from start to end indices, inclusive
		        for (int i = start; i <= end; i++) 
		        {
		            if (i >= 0 && i < durations.size())
		            {
		                totalDuration += durations.get(i).duration;
		            }
		        }

		        return totalDuration;
		    }


    
    
}
