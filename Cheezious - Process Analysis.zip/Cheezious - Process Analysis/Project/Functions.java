import java.io.File;
import java.util.Random;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class Functions 
{
	
	public String modifiedFile_Path;
	public ProcessCycleTimeCalculator cycleTime;
	public double processTime=0.0;
	
	public Functions()
	{
		modifiedFile_Path="";
		cycleTime=new ProcessCycleTimeCalculator();
	}
	// AddActivityTime Function
    public void addActivityTime(String filePath) throws Exception 
    {
    	// Creating file object
        File xmlFile = new File(filePath);
        // Create a random generator object
        Random random = new Random();
        
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(xmlFile);
        doc.getDocumentElement().normalize();

        // Get all the task elements
        NodeList taskList = doc.getElementsByTagName("Task");
       
        for (int i = 0; i < taskList.getLength(); i++) 
        {
            Element task = (Element) taskList.item(i);
            int duration = 5 + random.nextInt(11);
            task.setAttribute("duration", String.valueOf(duration));
        }

        // Saving the modified document 
        
        String newPath="NewVersion.xpdl";
        File newxmlFile=new File(newPath);
        
        TransformerFactory transformerFactory = TransformerFactory.newInstance(); // Enable to create a transformer object
        Transformer transformer = transformerFactory.newTransformer();
        // The DOM source
        DOMSource source = new DOMSource(doc);
        // The output store place or file (same existing file)
        StreamResult result = new StreamResult(newxmlFile);
        transformer.setOutputProperty(OutputKeys.INDENT, "yes"); // For indentation of the new XPDL file
        // Transforming DOM tree back to XML structure
        transformer.transform(source, result);
        
        modifiedFile_Path=newxmlFile.getAbsolutePath();
        
        System.out.println();
        System.out.println("The tasks has been assigned duration between 5-15 minutes successfully...");
        System.out.println("The XPDL file has been updated...");
        System.out.println("Modified File Path: "+modifiedFile_Path);
        System.out.println();
    }
    
    // CalculateCycleTime Function
    public double CalculateCT(String filepath) throws Exception
    {
    	File xmlFile = new File(filepath);
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(xmlFile);
        doc.getDocumentElement().normalize();

        // Get all task elements
        NodeList tasks = doc.getElementsByTagName("Task");
        double duration=0.0;
        System.out.println();
        System.out.println("--------------------------------------");
        System.out.println(" - Total Tasks: "+tasks.getLength());
        System.out.println("Tasks\t Durations\n");
        for (int i = 0; i < tasks.getLength(); i++) 
        {

            Element task=(Element) tasks.item(i);
            duration=Double.parseDouble(task.getAttribute("duration"));
            processTime+=duration;
            System.out.println(" - "+(i+1)+"\t"+duration+" minutes");
            
        }
        System.out.println("--------------------------------------");
        
        ProcessCycleTimeCalculator.parseDocument(filepath);
        
        return ProcessCycleTimeCalculator.calculateCycleTime();
        
        
        
        
    }
    
}
    

